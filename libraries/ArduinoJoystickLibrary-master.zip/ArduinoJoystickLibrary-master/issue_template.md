## Description of Issue
Enter description of issue here.

## Technical Details

- Arduino Board (e.g. Arduino Leonardo): 
- Host OS (e.g. Windows 10):
- Arduino IDE Version (e.g. 1.8.3):

## Sketch File that Reproduces Issue

~~~
Sketch file goes here (if applicable)
~~~

## Wiring Details

Any details about pin wirings that may be relevant.
