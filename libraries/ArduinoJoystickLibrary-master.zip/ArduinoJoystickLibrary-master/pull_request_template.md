Fixes # or Enhancement #

Changes proposed in this pull request:

- 
- 
- 

Contributors:
